from RssReader.html2text.cli import main

main()
