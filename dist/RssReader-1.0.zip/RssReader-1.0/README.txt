RSS Reader version 1.0 by AlexSpaceBy

++++++++++++++++++++
FOR WINDOWS (tested for Wondows 10 1903)
++++++++++++++++++++
Package installation:
=========================================
zip Installation:
=========================================
1. Unzip package to the desired directory.
2. Run Console with administrator privileges (run as Administrator).
3. In console go to directory where package was unpacked (...dirname/RssReader-v.1.2/).
4. Run the following command: "pip install ." (The dot after "install" is nesessary)
=========================================
zip Package Run:
=========================================
1. Run Console with administrator privileges (run as Administrator).
2. In console go to directory where package was unpacked (...dirname/RssReader-v.1.2/).
3. Run the following command: "python RssReader [url] [list of flags]"

Flags:
-v - Print the version of the program in console.
-h - Print the help message.
-b - Print logs from logJournal to console.
-j - Print news in JSON format to console.
-l - Limit the number of news topics.

Warning:
[url] is a positional argument, it is mandatory to enter this argument, if you use [-b], [-j], [-l] flags.
========================================
Log Journal:
========================================
Log Journal is stored in the (...dirname/RssReader-v.1.2/RssReader/logJournal.log)
========================================

+++++++++++++++++++++++++
STRUCTURE OF THE PROJECT
++++++++++++++++++++++++

RssReader
|---RssReader
|    |__init__.py
|    |__main__.py
|    |---args_parser.py
|    |---ecxeptions.py
|    |---feedparser.py
|    |---json_converter.py
|    |---logs.py
|    |---other.py
|    |---rss_reader.py
|    |---rss_parser.py
|    |
|    |---html2text
|        |-----__init__.py
|        |-----__main__.py
|        |-----cli.py
|        |-----config.py
|        |-----utils.py
|
|---setup.py
|---README.txt
|---LICENCE.txt

   
 