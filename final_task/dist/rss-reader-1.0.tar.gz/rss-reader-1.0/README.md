# Python RSS-reader 
Python RSS-reader is a command-line utility which receives RSS URL and prints results in human-readable format.

To start Python RSS-reader run one of the following commands
in command line:
```shell
python rss_reader.py "https://news.yahoo.com/rss/" --limit 1
```
```shell
python rss_reader.py "https://timesofindia.indiatimes.com/rssfeedstopstories.cms" --json --limit 1
```
```shell
python rss_reader.py "http://www.nato.int/cps/rss/en/natohq/rssFeed.xsl/rssFeed.xml" --limit 1
```

5 mains files of project:
* rss_reader.py - the file which runs the application
* ConsoleParse.py - contains code which parses arguments from console
* Entry.py - contains class Entry which represent an article
* Handler.py - contains class Handler which performes functions of processing objects Entry
* Logging.py - contains decorator for printing loggs in stdout

Structure of output when `--json` is selected:
```
{
  "Feed": "Yahoo News - Latest News & Headlines",
  "Title": "Trump Jr. tweets name of alleged whistleblower",
  "Date": "Wed, 06 Nov 2019 11:44:34 -0500",
  "Link": "https://news.yahoo.com/donald-trump-jr-tweets-name-of-whistleblower-164434463.html",
  "Links": [
    "https://news.yahoo.com/donald-trump-jr-tweets-name-of-whistleblower-164434463.html",
    "http://l.yimg.com/uu/api/res/1.2/2BQtOMLnlPTy3DNXkpQPIw--/YXBwaWQ9eXRhY2h5b247aD04Njt3PTEzMDs-/https://media-mbst-pub-ue1.s3.amazonaws.com/creatr-uploaded-images/2019-11/e7ce4300-00b0-11ea-abff-085279fefba1"
  ]
}
```