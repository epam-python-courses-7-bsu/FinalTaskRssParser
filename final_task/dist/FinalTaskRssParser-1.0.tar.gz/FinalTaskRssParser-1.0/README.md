# That's how it works

* Creating class RSSParser
* Using feedparser to get a page with function parse
* Then using output functions get info from the page
* Info (source link, image link, etc.) for every novelty pack in class Novelty
* Create a pack of news filled with Novelty class objects
* When a pack of news is done come back to rss_parser.py
* Here we prepare to output info according to arguments from console
* Checking arguments, output the info

# Storage of news
I have chosen 2 ways of collecting news: 
* Using JSON which I dump into the text file
* Putting information in readable view in the text file

I need JSON cache because I put my news here to get them in the future in list and then make
 a pack of Novelty class objects. 

## JSON view is the following: 
* Number of novelty
* Title
* Date and time when it was published
* Link for that novelty
* Description
* Image link
* Alternative text
* Main source link (Where it was published)

## Readable view of the text file is the following:
(The same as the JSON view)
* Number of novelty
* Title
* Date and time when it was published
* Link for that novelty
* Description
* Image link
* Alternative text
* Main source link (Where it was published)
