from rss_reader import rss_reader

if __name__ == "__main__":
    # execute only if run as a script
    rss_reader.main()
